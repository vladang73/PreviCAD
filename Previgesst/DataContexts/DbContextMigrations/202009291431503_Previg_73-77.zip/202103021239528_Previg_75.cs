namespace Previgesst.DataContexts.DbContextMigrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Previg_75 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Equipements", "NumeroEquipement", c => c.String(maxLength: 250));
            AddColumn("dbo.Equipements", "Model", c => c.String(maxLength: 250));
            AddColumn("dbo.Equipements", "Manufacturer", c => c.String(maxLength: 250));
            AddColumn("dbo.Equipements", "Task", c => c.String(maxLength: 250));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Equipements", "NumeroEquipement");
            DropColumn("dbo.Equipements", "Model");
            DropColumn("dbo.Equipements", "Manufacturer");
            DropColumn("dbo.Equipements", "Task");
        }
    }
}

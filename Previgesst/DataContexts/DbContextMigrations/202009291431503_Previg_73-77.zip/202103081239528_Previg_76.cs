namespace Previgesst.DataContexts.DbContextMigrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Previg_76 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Equipements", "Accessories", c => c.String(nullable: false, maxLength: 250));
            AddColumn("dbo.Equipements", "Energy", c => c.String(maxLength: 250));
            AddColumn("dbo.Equipements", "Deposit", c => c.String(maxLength: 250));
            AddColumn("dbo.Equipements", "Nomenclature", c => c.String(maxLength: 250));
            AddColumn("dbo.Equipements", "NumberOfSerie", c => c.String(maxLength: 250));
            AddColumn("dbo.Equipements", "YearOfProduction", c => c.Int());
            AddColumn("dbo.Equipements", "Function", c => c.String(maxLength: 250));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Equipements", "Accessories");
            DropColumn("dbo.Equipements", "Energy");
            DropColumn("dbo.Equipements", "Deposit");
            DropColumn("dbo.Equipements", "Nomenclature");
            DropColumn("dbo.Equipements", "NumberOfSerie");
            DropColumn("dbo.Equipements", "YearOfProduction");
            DropColumn("dbo.Equipements", "Function");
        }
    }
}

namespace Previgesst.DataContexts.DbContextMigrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Previg_77 : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.EquipementArticuloes",
                c => new
                    {
                        EquipementArticuloID = c.Int(nullable: false, identity: true),
                        EquipementId = c.Int(nullable: false),
                        Accessories = c.Int(nullable: false),
                        Energy = c.Int(nullable: false),
                        Deposit = c.Int(nullable: false),
                        Nomenclature = c.String(),
                    })
                .PrimaryKey(t => t.EquipementArticuloID)
                .ForeignKey("dbo.Equipements", t => t.EquipementId)
                .Index(t => t.EquipementId);
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.EquipementArticuloes", "EquipementId", "dbo.Equipements");
            DropIndex("dbo.EquipementArticuloes", new[] { "EquipementId" });
            DropTable("dbo.EquipementArticuloes");
        }
    }
}

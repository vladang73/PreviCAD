namespace Previgesst.DataContexts.DbContextMigrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Previg_761 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Equipements", "Accessories", c => c.String());
            AddColumn("dbo.Equipements", "Energy", c => c.String());
            AddColumn("dbo.Equipements", "Deposit", c => c.String());
            AddColumn("dbo.Equipements", "Nomenclature", c => c.String());
            AddColumn("dbo.Equipements", "NumberOfSerie", c => c.String());
            AddColumn("dbo.Equipements", "YearOfProduction", c => c.Int());
            AddColumn("dbo.Equipements", "Function", c => c.String());
        }
        
        public override void Down()
        {
            DropColumn("dbo.Equipements", "Function");
            DropColumn("dbo.Equipements", "YearOfProduction");
            DropColumn("dbo.Equipements", "NumberOfSerie");
            DropColumn("dbo.Equipements", "Nomenclature");
            DropColumn("dbo.Equipements", "Deposit");
            DropColumn("dbo.Equipements", "Energy");
            DropColumn("dbo.Equipements", "Accessories");
        }
    }
}
